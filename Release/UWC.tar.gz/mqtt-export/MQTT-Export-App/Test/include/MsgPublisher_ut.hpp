/*
 * MsgPublisher_ut.h
 *
 *  Created on: 07-Feb-2020
 *      Author: user
 */

#ifndef MSGPUBLISHER_UT_H_
#define MSGPUBLISHER_UT_H_


int Publisher_Main(int argc, char** argv);


#endif /* MSGPUBLISHER_UT_H_ */

/************************************************************************************
 * The source code contained or described herein and all documents related to
 * the source code ("Material") are owned by Intel Corporation. Title to the
 * Material remains with Intel Corporation.
 *
 * No license under any patent, copyright, trade secret or other intellectual
 * property right is granted to or conferred upon you by disclosure or delivery of
 * the Materials, either expressly, by implication, inducement, estoppel or otherwise.
 ************************************************************************************/

#include "PeriodicReadFeature.hpp"
#include "NetworkInfo.hpp"
#include "ZmqHandler.hpp"
#include "PublishJson.hpp"
#include "PeriodicRead.hpp"
#include <netdb.h>
#include <ifaddrs.h>
#include <string.h>
#include <cstring>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include "ModbusOnDemandHandler.hpp"
#include "YamlUtil.hpp"
#include "ConfigManager.hpp"
#include "Logger.hpp"
#ifdef UNIT_TEST
#include <gtest/gtest.h>
#endif

extern "C" {
#include <safe_lib.h>
}

std::mutex mtx;
std::condition_variable cv;
bool g_stop = false;

#define APP_VERSION "0.0.4.5"
#define TIMER_TICK_FREQ 1000 // in microseconds

/// flag to stop all running threads
extern std::atomic<bool> g_stopThread;

/**
 * Populate polling data
 */
void populatePollingRefData()
{
	DO_LOG_DEBUG("Start");

	using network_info::CUniqueDataPoint;
	using network_info::eEndPointType;
	// 1. get unique point list
	// 2. check if polling is enabled for that point
	// 3. check if zmqcontext is available
	// 4. if 2 and 3 are yes, create polling ref data

	const std::map<std::string, CUniqueDataPoint> &mapUniquePoint = network_info::getUniquePointList();
	int iCount = 1;
	for(auto &pt: mapUniquePoint)
	{
		const CUniqueDataPoint &a = mapUniquePoint.at(pt.first);
		if(0 == a.getDataPoint().getPollingConfig().m_uiPollFreq)
		{
			DO_LOG_INFO("Polling is not set for "+ a.getDataPoint().getID());
			// Polling frequency is not set
			continue; // go to next point
		}
		try
		{
			std::string sTopic = PublishJsonHandler::instance().getPolledDataTopic();

			DO_LOG_DEBUG("Topic for context search: " + sTopic);

			std::cout << iCount++ << ". Point to poll: " << a.getID() << ", RT: "
					<< a.getDataPoint().getPollingConfig().m_bIsRealTime << ", Freq: "
					<< a.getDataPoint().getPollingConfig().m_uiPollFreq << std::endl;
			zmq_handler::stZmqContext &busCTX = zmq_handler::getCTX(sTopic);
			zmq_handler::stZmqPubContext &pubCTX = zmq_handler::getPubCTX(sTopic);

			uint8_t uiFuncCode = 0;
			switch(a.getDataPoint().getAddress().m_eType)
			{
			case network_info::eEndPointType::eCoil:
				uiFuncCode = 1;
				break;
			case network_info::eEndPointType::eDiscrete_Input:
				uiFuncCode = 2;
				break;
			case network_info::eEndPointType::eHolding_Register:
				uiFuncCode = 3;
				break;
			case network_info::eEndPointType::eInput_Register:
				uiFuncCode = 4;
				break;
			}

			CRefDataForPolling objRefPolling{a, busCTX, pubCTX, uiFuncCode};

			CTimeMapper::instance().insert(a.getDataPoint().getPollingConfig().m_uiPollFreq, objRefPolling);

			DO_LOG_INFO("Polling is set for " +
						a.getDataPoint().getID() +
						", FunctionCode " +
						to_string((unsigned)uiFuncCode) +
						", frequency " +
						to_string(a.getDataPoint().getPollingConfig().m_uiPollFreq) +
						", RT " +
						to_string(a.getDataPoint().getPollingConfig().m_bIsRealTime));
		}
		catch(std::exception &e)
		{
			DO_LOG_FATAL("Exception " +
						(string)e.what() +
						"in processing " +
						a.getDataPoint().getID());
		}
	}

	DO_LOG_DEBUG("End");
}

/**
 * checks whether to stop thread execution
 * @return 	true : on success,
 * 			false : on error
 */
bool exitMainThread(){return g_stopThread;};

/**
 *
 * DESCRIPTION
 * This function is used to check keys from given JSON
 *
 * @param root [in] argument count
 * @param a_sKeyName [in] key from JSON
 *
 * @return boolean [out] return true on success and false on failure
 */
bool isElementExistInJson(cJSON *root, std::string a_sKeyName)
{
	bool bRetVal = false;
	cJSON *pBaseptr = cJSON_GetObjectItem(root, a_sKeyName.c_str());
	if(NULL != pBaseptr)
	{
		// key found in json
		bRetVal = true;
	}
	return bRetVal;
}

/** This function is used to read environment variable
 *
 * @sEnvVarName : environment variable to be read
 * @storeVal : variable to store env variable value
 * @return: true/false based on success or error
 */
bool CommonUtils::readEnvVariable(const char *pEnvVarName, string &storeVal)
{
	if(NULL == pEnvVarName)
	{
		return false;
	}
	bool bRetVal = false;
	char *cEvar = getenv(pEnvVarName);
	if (NULL != cEvar)
	{
		bRetVal = true;
		std::string tmp (cEvar);
		storeVal = tmp;
		DO_LOG_INFO(std::string(pEnvVarName) + " environment variable is set to ::" + storeVal);
		std::cout << std::string(pEnvVarName) + " environment variable is set to ::" + storeVal << endl;
	}
	else
	{
		DO_LOG_ERROR(std::string(pEnvVarName) + " environment variable is not found");
		cout << std::string(pEnvVarName) + " environment variable is not found" <<endl;
	}
	return bRetVal;
}

/** This function is used to read common environment variables
 *
 * @return: true/false based on success or error
 */
bool CommonUtils::readCommonEnvVariables()
{
	bool bRetVal = false;
	std::list<std::string> topicList{"PolledData", "PolledData_RT", "ReadResponse", "ReadResponse_RT", "WriteResponse",
		"WriteResponse_RT", "ReadRequest", "ReadRequest_RT", "WriteRequest", "WriteRequest_RT", "SITE_LIST_FILE_NAME", "DEV_MODE"};

	std::map <std::string, std::string> envTopics;

	for (auto &topic : topicList)
	{
		std::string envVar = "";
		bRetVal = readEnvVariable(topic.c_str(), envVar);
		if(!bRetVal)
		{
			return false;
		}
		else
		{
			envTopics.emplace(topic, envVar);
		}
	}

	PublishJsonHandler::instance().setPolledDataTopic(envTopics.at("PolledData"));
	PublishJsonHandler::instance().setPolledDataTopicRT(envTopics.at("PolledData_RT"));
	PublishJsonHandler::instance().setSReadResponseTopic(envTopics.at("ReadResponse"));
	PublishJsonHandler::instance().setSReadResponseTopicRT(envTopics.at("ReadResponse_RT"));
	PublishJsonHandler::instance().setSWriteResponseTopic(envTopics.at("WriteResponse"));
	PublishJsonHandler::instance().setSWriteResponseTopicRT(envTopics.at("WriteResponse_RT"));
	PublishJsonHandler::instance().setSReadRequestTopic(envTopics.at("ReadRequest"));
	PublishJsonHandler::instance().setSReadRequestTopicRT(envTopics.at("ReadRequest_RT"));
	PublishJsonHandler::instance().setSWriteRequestTopic(envTopics.at("WriteRequest"));
	PublishJsonHandler::instance().setSWriteRequestTopicRT(envTopics.at("WriteRequest_RT"));
	PublishJsonHandler::instance().setSiteListFileName(envTopics.at("SITE_LIST_FILE_NAME"));


	string devMode = envTopics.at("DEV_MODE");
	transform(devMode.begin(), devMode.end(), devMode.begin(), ::toupper);

	if (devMode == "TRUE")
	{
		PublishJsonHandler::instance().setDevMode(true);
		DO_LOG_INFO("DEV_MODE is set to true");
		cout << "DEV_MODE is set to true\n";

	}
	else if (devMode == "FALSE")
	{
		PublishJsonHandler::instance().setDevMode(false);
		DO_LOG_INFO("DEV_MODE is set to false");
		cout << "DEV_MODE is set to false\n";
	}
	else
	{
		/// default set to false
		DO_LOG_ERROR("Invalid value for DEV_MODE env variable");
		DO_LOG_INFO("Set the dev mode to default (i.e. true)");
		cout << "DEV_MODE is set to default false\n";
	}

	return bRetVal;
}
/**
 *
 * DESCRIPTION
 * This function is entry point for application
 *
 * @param argc [in] argument count
 * @param argv [in] argument value
 *
 * @return int [out] return 1 on success
 */
int main(int argc, char* argv[])
{
	DO_LOG_DEBUG("Start");

	try
	{
		DO_LOG_DEBUG("Starting Modbus_App ...");

		DO_LOG_INFO("Modbus container app version is set to :: " + std::string(APP_VERSION));
		cout <<"\nModbus container app version is :: " + std::string(APP_VERSION) << "\n"<<endl;

		// load global configuration for container real-time setting
		bool bRetVal = globalConfig::loadGlobalConfigurations();
		if(!bRetVal)
		{
			DO_LOG_INFO("Global configuration is set with some default parameters");
			cout << "\nGlobal configuration is set with some default parameters\n\n";
		}
		else
		{
			DO_LOG_INFO("Global configuration is set successfully");
			cout << "\nGlobal configuration for container real-time is set successfully\n\n";
		}

		string sAppName;
		if(!CommonUtils::readEnvVariable("AppName", sAppName))
		{
			exit(1);
		}

		PublishJsonHandler::instance().setAppName(sAppName);

		if (!CommonUtils::readCommonEnvVariables())
		{
			DO_LOG_ERROR("Required env variables are not set.");
			std::cout << "Required common env variables are not set.\n";
			exit(1);
		}

		string cutOff;
		if(!CommonUtils::readEnvVariable("CUTOFF_INTERVAL_PERCENTAGE", cutOff))
		{
			DO_LOG_INFO("CUTOFF_INTERVAL_PERCENTAGE env variables are not set.");
			cout << "CUTOFF_INTERVAL_PERCENTAGE env variables are not set."<<endl;
			std::cout << "setting it to default i.e. 90 \n";
			DO_LOG_INFO("setting it to default i.e. 90");
			PublishJsonHandler::instance().setCutoffIntervalPercentage(90);
		}
		else
		{
			PublishJsonHandler::instance().setCutoffIntervalPercentage(atoi(cutOff.c_str()));
		}
		std::cout << "Cutoff is set to: "
				<< PublishJsonHandler::instance().getCutoffIntervalPercentage() << std::endl;

#ifndef MODBUS_STACK_TCPIP_ENABLED

		string sPortName, sBaudrate, sParity;
		eParity parity;
		if (!((CommonUtils::readEnvVariable("PORT_NAME", sPortName)) &&
				(CommonUtils::readEnvVariable("BAUD_RATE", sBaudrate)) &&
				(CommonUtils::readEnvVariable("PARITY", sParity))))
		{
			DO_LOG_ERROR("Required environment variables are not found for RTU");
			std::cout << "Required environment variables are not found for RTU" << endl;
			exit(1);
		}
		else
		{
			DO_LOG_INFO("Required environment variables are found for RTU");
		}

		if(sParity == "N" || sParity == "n" ||
				sParity == "E" || sParity == "e" ||
				sParity == "O" || sParity == "o")
		{
			parity = (sParity == "N" || sParity == "n") ? eNone : (sParity == "O" || sParity == "o") ? eOdd : eEven;
		}
		else
		{
			DO_LOG_ERROR("Set Parity is wrong for RTU. Set correct parity N/E/O");
			std::cout << "Set Parity \"" << sParity << "\" is wrong for RTU. Set correct parity N/E/O" << endl;
			exit(1);
		}
		cout << "********************************************************************"<<endl;
		cout << "Modbus RTU container is running with below configuration.."<<endl;
		cout<<"Baud rate = "<< stoi(sBaudrate)<< endl;
		cout<<"Port Name = "<< sPortName<< endl;
		cout<<"Parity = "<< sParity << endl;
		cout << "********************************************************************"<<endl;

		DO_LOG_INFO("Modbus RTU container is running with below configuration..");

		DO_LOG_INFO("Baud rate = " + sBaudrate + " \n" +
				"Port Name = " + sPortName + " \n" + "Parity = " + sParity + " \n");

		int fd;
		long l_serialPortOpenDelay;
		std::string s_serialPortOpenDelay;
		std::string::size_type sz;   // alias of size_t
		if(CommonUtils::readEnvVariable("SERIAL_PORT_RETRY_INTERVAL", s_serialPortOpenDelay))
		{
			l_serialPortOpenDelay = std::stol (s_serialPortOpenDelay, &sz);
		}
		else
		{
			l_serialPortOpenDelay = 60; //Default delay 01 min
		}

		do{
			fd = initSerialPort((uint8_t*)(sPortName.c_str()),
					stoi(sBaudrate),
					parity);
			if(fd < 0)
			{
				cout << "Failed to initialize serial port for RTU."<<endl;
				cout << "Connect the RTU device to serial port"<<endl;
				//cout << "Container will restart until the serial port is connected."<<endl;
				DO_LOG_ERROR("Failed to initialize serial port for RTU.");

				DO_LOG_ERROR("File descriptor is set to ::" + to_string(fd));

				cout << "Error:: File descriptor is set to :: " << fd << endl;
				cout << "Attempting to Open Serial Port again :: " << endl;
				//return -1;
			}
			else
			{
				cout << "Initialize serial port for RTU is successful"<<endl;
				DO_LOG_INFO("File descriptor is set to ::" + to_string(fd));
				cout << "File descriptor is set to :: " << fd << endl;
			}
			sleep(l_serialPortOpenDelay);
		}while(fd < 0);
#endif

		// Setup signal handlers

		long iResponseTimeout, iInterframeDelay;
		std::string sResponseTimeout, sInterframeDelay;
		std::string::size_type sizeVar;   // alias of size_t
		if(CommonUtils::readEnvVariable("RESPONSE_TIMEOUT_MS", sResponseTimeout))
		{
			iResponseTimeout = std::stol (sResponseTimeout, &sizeVar);
		}
		else
		{
			iResponseTimeout = 80; //Default response time
		}

		if(CommonUtils::readEnvVariable("INTERFRAME_DELAY_MS", sInterframeDelay))
		{
			iInterframeDelay = std::stol (sInterframeDelay, &sizeVar);
		}
		else
		{
			iInterframeDelay = 0; //Default interframe delay
		}

		stDevConfig_t stDevConf;
		stDevConf.m_lInterframedelay = iInterframeDelay;
		stDevConf.m_lResponseTimeout = iResponseTimeout;
		if(STACK_NO_ERROR != AppMbusMaster_SetStackConfigParam(&stDevConf))
		{
			std::cout << "Error: Exiting. Failed to set stack  config parameters"<< std::endl;
			DO_LOG_ERROR("Failed to set stack  config parameters");
			return -1;
		}
		else
		{
			std::cout << "Success :: modbus stack set config successful" << std::endl;
			DO_LOG_INFO("modbus stack set config successful");
		}

		uint8_t	u8ReturnType = AppMbusMaster_StackInit();
		if(0 != u8ReturnType)
		{
			DO_LOG_ERROR("Exiting. Failed to initialize modbus stack:" +
						to_string(u8ReturnType));

			std::cout << "Error: Exiting. Failed to initialize modbus stack:" << (unsigned)u8ReturnType << std::endl;
			exit(1);
		}
		else
		{
			std::cout << "\nSuccess :: modbus stack initialization successful" << std::endl;
			DO_LOG_INFO("modbus stack initialization successful");
		}

		// Initializing all the pub/sub topic base context for ZMQ
		if(const char* pcPubTopic = std::getenv("PubTopics"))
		{
			DO_LOG_INFO("List of topic configured for Pub are :: " + std::string(pcPubTopic));

			bool bRes = zmq_handler::prepareCommonContext("pub");
			if(!bRes)
			{
				DO_LOG_ERROR("Context creation failed for pub topic ");
			}
		}
		if(const char* pcSubTopic = std::getenv("SubTopics"))
		{
			DO_LOG_INFO("List of topic configured for Sub are :: " + std::string(pcSubTopic));

			bool bRetVal = zmq_handler::prepareCommonContext("sub");
			if(!bRetVal)
			{
				DO_LOG_ERROR("Context creation failed for sub topic ");
			}
		}

#ifdef MODBUS_STACK_TCPIP_ENABLED
		/// store the yaml files in data structures
		network_info::buildNetworkInfo(true);
		DO_LOG_INFO("Modbus container application is set to TCP mode");
		cout << "Modbus container application is set to TCP mode.." << endl;
#else

		// Setting RTU mode
		network_info::buildNetworkInfo(false);
		DO_LOG_INFO("Modbus container application is set to RTU mode");
		cout << "Modbus container application is set to RTU mode.." << endl;
#endif

		if(false == onDemandHandler::Instance().isWriteInitialized())
		{
			DO_LOG_ERROR("modWriteHandler is not initialized");
		}
		else
		{
			DO_LOG_DEBUG("modWriteHandler is properly initialized");
			/// On-Demand request initializer thread.
			onDemandHandler::Instance().createOnDemandListener();
		}

		// ZMQ contexts are built
		// Network device data and unique point data are also available
		// Lets build: reference data for polling
		populatePollingRefData();

		if(false == CPeriodicReponseProcessor::Instance().isInitialized())
		{
			DO_LOG_ERROR("CPeriodicReponseProcessor is not initialized");
		}
		else
		{
			DO_LOG_INFO("CPeriodicReponseProcessor is properly initialized");
			CPeriodicReponseProcessor::Instance().initRespHandlerThreads();
		}


#ifdef UNIT_TEST
		//::testing::GTEST_FLAG(filter) ="*CConfigManager_ut*";
		::testing::InitGoogleTest(&argc, argv);
		return RUN_ALL_TESTS();
#endif

		DO_LOG_INFO("Configuration done. Starting operations.");
		CTimeMapper::instance().initTimerFunction();

		// Get best possible polling frequency
		uint32_t ulMinFreq = CTimeMapper::instance().getMinTimerFrequency();
		std::cout << "Best possible minimum frequency in milliseconds: " << ulMinFreq << std::endl;
		std::cout << "Starting periodic timer\n";
		PeriodicTimer::timer_start(ulMinFreq);
		std::cout << "Timer is started..\n";

		std::unique_lock<std::mutex> lck(mtx);
		cv.wait(lck,exitMainThread);

		DO_LOG_INFO("Condition variable is set for application exit.");

		DO_LOG_INFO("Exiting the application gracefully.");
		cout << "************************************************************************************************" <<endl;
		cout << "********************** Exiting modbus container ***********" <<endl;
		cout << "************************************************************************************************" <<endl;

		return EXIT_SUCCESS;
	}
	catch (const std::exception &e)
	{
		std::cout << "Exception in main::"<<"fatal::Error in getting arguments: "<<e.what()<< endl;
		DO_LOG_FATAL("fatal::Error in getting arguments: " +
					(string)e.what());

		return EXIT_FAILURE;
	}
	DO_LOG_DEBUG("End");

	return EXIT_SUCCESS;
}
